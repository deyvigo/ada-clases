import java.util.Scanner;

import src.ArbolBinario;
import src.Nodo;

public class PostOrden {

  public static void main(String[] args) {
    ArbolBinario ab = new ArbolBinario();
    // ab.addNodo(new Nodo(50));
    // ab.addNodo(new Nodo(15));
    // ab.addNodo(new Nodo(26));
    // ab.addNodo(new Nodo(18));
    // ab.addNodo(new Nodo(52));
    // ab.addNodo(new Nodo(35));
    // ab.addNodo(new Nodo(45));
    // ab.addNodo(new Nodo(12));
    // ab.addNodo(new Nodo(62));

    // ab.mostrarPostOrden();
    menu(ab);
  }

  public static void menu (ArbolBinario ab) {
    Scanner scanner = new Scanner(System.in);
    int opcion;
    do {
      System.out.println("1. Agregar nodo al arbol binario. \n2. Mostrar arbol en postorden.");
      opcion = scanner.nextInt();
      switch (opcion) {
        case 1:
          System.out.println("Digite el valor del nodo: ");
          ab.addNodo(new Nodo(scanner.nextInt()));
          break;
        case 2:
          ab.mostrarPostOrden();
          break;
      }
    } while (opcion == 1 || opcion == 2);
    scanner.close();
  }
    
}
