package src;

public class Task {
  public int position;
  public int benefit;
  public int plazo;
  
  public Task(int position, int benefit, int plazo) {
    this.position = position;
    this.benefit = benefit;
    this.plazo = plazo;
  }
}
